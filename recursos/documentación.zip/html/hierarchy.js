var hierarchy =
[
    [ "Aparcamiento_Inteligente_2.servicios.DBServicio", "class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio.html", null ],
    [ "Aparcamiento_Inteligente_2.servicios.DialogosNavegacion", "class_aparcamiento___inteligente__2_1_1servicios_1_1_dialogos_navegacion.html", null ],
    [ "Aparcamiento_Inteligente_2.servicios.FaceAPI", "class_aparcamiento___inteligente__2_1_1servicios_1_1_face_a_p_i.html", null ],
    [ "Aparcamiento_Inteligente_2.servicios.Nube", "class_aparcamiento___inteligente__2_1_1servicios_1_1_nube.html", null ],
    [ "RequestMessage", null, [
      [ "Aparcamiento_Inteligente_2.servicios.ClienteSeleccionadoMessage", "class_aparcamiento___inteligente__2_1_1servicios_1_1_cliente_seleccionado_message.html", null ],
      [ "Aparcamiento_Inteligente_2.servicios.VehiculoSeleccionadoMessageDesdeCliente", "class_aparcamiento___inteligente__2_1_1servicios_1_1_vehiculo_seleccionado_message_desde_cliente.html", null ],
      [ "Aparcamiento_Inteligente_2.servicios.VehiculoSeleccionadoMessageDesdeVehiculo", "class_aparcamiento___inteligente__2_1_1servicios_1_1_vehiculo_seleccionado_message_desde_vehiculo.html", null ]
    ] ]
];