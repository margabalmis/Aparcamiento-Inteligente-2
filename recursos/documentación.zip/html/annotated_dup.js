var annotated_dup =
[
    [ "Aparcamiento_Inteligente_2", "namespace_aparcamiento___inteligente__2.html", [
      [ "servicios", "namespace_aparcamiento___inteligente__2_1_1servicios.html", [
        [ "ClienteSeleccionadoMessage", "class_aparcamiento___inteligente__2_1_1servicios_1_1_cliente_seleccionado_message.html", null ],
        [ "DBServicio", "class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio.html", "class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio" ],
        [ "DialogosNavegacion", "class_aparcamiento___inteligente__2_1_1servicios_1_1_dialogos_navegacion.html", "class_aparcamiento___inteligente__2_1_1servicios_1_1_dialogos_navegacion" ],
        [ "FaceAPI", "class_aparcamiento___inteligente__2_1_1servicios_1_1_face_a_p_i.html", "class_aparcamiento___inteligente__2_1_1servicios_1_1_face_a_p_i" ],
        [ "Nube", "class_aparcamiento___inteligente__2_1_1servicios_1_1_nube.html", "class_aparcamiento___inteligente__2_1_1servicios_1_1_nube" ],
        [ "VehiculoSeleccionadoMessageDesdeCliente", "class_aparcamiento___inteligente__2_1_1servicios_1_1_vehiculo_seleccionado_message_desde_cliente.html", null ],
        [ "VehiculoSeleccionadoMessageDesdeVehiculo", "class_aparcamiento___inteligente__2_1_1servicios_1_1_vehiculo_seleccionado_message_desde_vehiculo.html", null ]
      ] ]
    ] ]
];