var searchData=
[
  ['clienteseleccionadomessage_0',['ClienteSeleccionadoMessage',['../class_aparcamiento___inteligente__2_1_1servicios_1_1_cliente_seleccionado_message.html',1,'Aparcamiento_Inteligente_2::servicios']]]
];
