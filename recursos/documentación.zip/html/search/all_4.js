var searchData=
[
  ['faceapi_0',['FaceAPI',['../class_aparcamiento___inteligente__2_1_1servicios_1_1_face_a_p_i.html',1,'Aparcamiento_Inteligente_2::servicios']]]
];
