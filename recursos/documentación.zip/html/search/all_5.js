var searchData=
[
  ['marcainsertone_0',['MarcaInsertOne',['../class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio.html#a9b342b67ef9fb04b8b0ed8220b16ce48',1,'Aparcamiento_Inteligente_2::servicios::DBServicio']]],
  ['marcasfindmarca_1',['MarcasFindMarca',['../class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio.html#a0ff4e7a26fa5cf18bac4b4f5b7d44b06',1,'Aparcamiento_Inteligente_2::servicios::DBServicio']]],
  ['marcasgetall_2',['MarcasGetAll',['../class_aparcamiento___inteligente__2_1_1servicios_1_1_d_b_servicio.html#ababe355bcd9181b0bcd3163bf12ae388',1,'Aparcamiento_Inteligente_2::servicios::DBServicio']]]
];
